import { Checkers } from './checkers';

describe('Checkers', () => {
  it('should create an instance', () => {
    expect(new Checkers()).toBeTruthy();
  });
});
