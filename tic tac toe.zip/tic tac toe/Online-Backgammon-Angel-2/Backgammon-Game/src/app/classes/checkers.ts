export class Checkers {
    type : boolean; //true is white / false is black
    image: string; //location of the Checker on the bord

    constructor(type, img) {
        type = this.type;
        img = this.image;
    }
}